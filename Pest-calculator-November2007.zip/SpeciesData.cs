//  Copyright 2006 University of Wisconsin
//  Authors:  Robert M. Scheller
//  License:  Available at  
//  http://landis.forest.wisc.edu/developers/LANDIS-IISourceCodeLicenseAgreement.pdf

using System.Collections.Generic;

namespace Landis.PestCalc
{
    /// <summary>
    /// Weather parameters for each month.
    /// </summary>
    public interface ISpeciesData
    {

        string Name{get;set;}
        double AllowableDrought{get;set;}
        double MinGDD{get;set;}
        double MaxGDD{get;set;}
        int MinJanTemp{get;set;}
        int NTolerance{get; set;}

    }
}



namespace Landis.PestCalc
{

    public class SpeciesData
    : ISpeciesData
    {

        private string name;
        private double allowableDrought;
        private double minGDD;
        private double maxGDD;
        private int minJanTemp;
        private int nTolerance;

        public string Name
        {
            get {
                return name;
            }
            set {
                name = value;
            }
        }

        public double AllowableDrought
        {
            get {
                return allowableDrought;
            }
            set {
                allowableDrought = value;
            }
        }
        public double MinGDD
        {
            get {
                return minGDD;
            }
            set {
                minGDD = value;
            }
        }
        public double MaxGDD
        {
            get {
                return maxGDD;
            }
            set {
                maxGDD = value;
            }
        }

        public int MinJanTemp
        {
            get {
                return minJanTemp;
            }
            set {
                minJanTemp = value;
            }
        }

        public int NTolerance
        {
            get {
                return nTolerance;
            }
            set {
                nTolerance = value;
            }
        }
        public SpeciesData(
                            string name,
                            double allowableDrought,
                            double minGDD,
                            double maxGDD,
                            int minJanTemp,
                            int nTolerance
                            )
        {
            this.name = name;
            this.allowableDrought = allowableDrought;
            this.minGDD = minGDD;
            this.maxGDD = maxGDD;
            this.minJanTemp = minJanTemp;
            this.nTolerance = nTolerance;
        }
        
        public SpeciesData()
        {
        }
        
    }
}
